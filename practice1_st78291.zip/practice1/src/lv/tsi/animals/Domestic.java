package lv.tsi.animals;

public interface Domestic {
	public static void printName() { }
}
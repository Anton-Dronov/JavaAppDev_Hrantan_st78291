package lv.tsi.sync;

public class TaskManager {
	public synchronized void performTask(int taskId, String name) {
		System.out.println(name + " : " + taskId);
		try {
			Thread.sleep(4);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(name + " : " + taskId);
	}
}
class TaskThread extends Thread{
	private TaskManager task;
	private String name;
	private int taskId;
	TaskThread(String name, int taskId, TaskManager task){
		this.name = name;
		this.taskId = taskId;
		this.task = task;
	}
	public void run() {
		task.performTask(taskId, name);
	}
}
class SyncMain{
	public static void main(String[] args) {
		final TaskManager OB = new TaskManager();
		TaskThread first = new TaskThread("first", 1, OB);
		TaskThread second = new TaskThread("second", 2, OB);
		first.start();
		try {
			Thread.sleep(2);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		second.start();
	}
}
package lv.tsi.priority;

public class PriorityThread extends Thread{
	private String name;
	PriorityThread(String name){
		this.name = name;
	}
	public void run() {
		for (int i = 0; i < 100; i++) {
			System.out.println(name + i);
			try {
				if (name.equals("min")) {
					Thread.sleep(12);
				} else if (name.equals("max")) {
					Thread.sleep(8);
				} else {
					Thread.sleep(10);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
class PriorityMain{
	public static void main(String[] args) {
		PriorityThread min = new PriorityThread("min");
		PriorityThread norm = new PriorityThread("norm");
		PriorityThread max = new PriorityThread("max");
		min.start();
		norm.start();
		max.start();
	}
}

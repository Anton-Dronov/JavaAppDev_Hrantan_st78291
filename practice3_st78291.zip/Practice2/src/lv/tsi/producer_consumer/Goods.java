package lv.tsi.producer_consumer;

public class Goods {
	private long amount;
	Goods(long amount){
		this.amount = amount;
	}
	public synchronized void produce(long amount1) {
		if (amount1 != 0) {
			notify();
		} else {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	public synchronized long consume() {
		if (amount != 0) {
			notify();
			return amount;
		} else {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return 0;
		}
	}
	public void NewAmount(long amount) {
		this.amount = amount;
	}
	public long getAmount() {
		return amount;
	}
}
class Producer extends Thread{
	private Goods good;
	Producer(Goods good){
		this.good = good;
	}
	public void run() {
		while(true) {
			long pro = Math.round(Math.random()*100);
			good.NewAmount(pro);
			System.out.println("Produced: " + pro);
		}
	}
}
class Consumer extends Thread{
	private Goods good;
	Consumer(Goods good){
		this.good = good;
	}
	public void run() {
		while(true) {
			System.out.println("Consumed: " + good.getAmount());
		}
	}
}
class ProducerConsumerMain{
	public static void main(String[] args) {
		Goods GD = new Goods(5);
		Producer PRD = new Producer(GD);
		Consumer CNS = new Consumer(GD);
		PRD.start();
		CNS.start();
	}
}
package lv.tsi.queue;

public class AddingThread extends Thread{
	private BlockingQueue BackYou;
	AddingThread(BlockingQueue BaQ){
		BackYou = BaQ;
	}
	public void run() {
		for (int i = 1; i < 4; i++) {
			String elem = "Element";
			elem += i; 
			BackYou.setSt(i-1, elem);
			System.out.println(elem + " is added.");
		}
	}
}
class TakingThread extends Thread{
	private BlockingQueue BackYou;
	TakingThread(BlockingQueue BaQ){
		BackYou = BaQ;
	}
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		for (int i = 1; i < 4; i++) {
			System.out.println(BackYou.getSt(i-1));
		}
	}
}
class BlockingQueue{
	private String[] st = new String[10];
	public String getSt(int Id) {
		return st[Id];
	}
	public void setSt(int Id, String set) {
		st[Id] = set;
	}
}
class BlockingMain{
	public static void main(String[] args) {
		BlockingQueue Qub = new BlockingQueue();
		AddingThread aQ = new AddingThread(Qub);
		TakingThread tQ = new TakingThread(Qub);
		aQ.start();
		tQ.start();
	}
}
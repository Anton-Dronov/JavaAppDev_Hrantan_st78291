package lv.tsi.lamda;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ListProcessingWithStreams {
	public static void main(String[] args) {
		
		List<String> list = Arrays.asList("a1","c3","a2","a3","b3","b2","c1","c2","b1");
		System.out.println(list.get(0));
		
		for(String itlist : list) {
			System.out.print(itlist.toUpperCase() + ", ");
		}
		
		System.out.println();
		
		for(String itlist : list) {
			if (itlist.indexOf("b") == 0) {
				System.out.print(itlist + ", ");
			}
		}
		
		System.out.println();
		
		Collections.sort(list);
		
		for(String itlist : list) {
			if (itlist.indexOf("c") == 0) {
				System.out.print(itlist.toUpperCase() + ", ");
			}
		}
	}
}
